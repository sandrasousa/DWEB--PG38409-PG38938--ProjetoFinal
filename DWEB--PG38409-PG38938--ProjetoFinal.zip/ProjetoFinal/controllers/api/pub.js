var Pub = require('../../models/api/pub')

//listar publicações no feed
module.exports.listar = () => {
    return Pub
        .find()
        .sort({dataInicio: -1})
        .exec()
}

//listar proprias publicações 
module.exports.verPublicacoes = (uid) => {
    return Pub
    .find({autor:uid})
    .sort({dataInicio: -1})
    .exec()
}

//consultar publicações por id
module.exports.consultar = (pid) => {
    return Pub
        .findOne({_id: pid})
        .exec()
}

//listar publicações por #
module.exports.listarPalavra = palavra => {
    return Pub
        .find({palavra: palavra})
        .sort({dataInicio: -1})
        .exec()
}

//listar publicações por tipo de evento
module.exports.listarTipo = tipo => {
    return Pub
        .find({tipo: tipo})
        .sort({dataInicio: -1})
        .exec()
}

//listar publicações por tipo de evento
module.exports.listarLocal = local => {
    return Pub
        .find({local: local})
        .sort({dataInicio: -1})
        .exec()
}

//inserir pubs
module.exports.inserir = pub => {
    console.log(pub)
    return Pub.create(pub)
}

//apagar pub
module.exports.apagar = (pid) => {
    console.log(pid)
    return Pub
        .findOneAndRemove({_id: pid.idPub})
}

//comentar pub
module.exports.comentar = (pid) => {
    console.log(pid)
    var coment = {
        autorID: pid.autorID,
        autorNome: pid.autorNome,
        comentario: pid.comentario,
        data:pid.data
    }
    return Pub
        .findByIdAndUpdate({_id: pid._id},{  $addToSet : {comentarios:coment}})
} 

//like pub
module.exports.like = (pid) => {
    console.log(pid)
    var novos_likes = parseInt(pid.likes) + 1
    console.log(novos_likes)
    return Pub
        .findByIdAndUpdate({_id: pid._id},{  $set : {likes_count:novos_likes}})
} 

//editar pub
module.exports.editar = (pid) => {
    console.log(pid)
    return Pub
       .findByIdAndUpdate({_id: pid.idPub},{  
           $set : {
            estado: pid.estado, 
            nome: pid.nome, 
            local: pid.local, 
            descricao: pid.descricao,
            dataInicio: pid.dataInicio,
            dataFim: pid.dataFim,
            tipo: pid.tipo,
            anexo: pid.anexo,
            palavra: pid.palavra
       }})
} 
