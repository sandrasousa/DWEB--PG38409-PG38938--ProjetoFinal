var User = require('../../models/api/user')
var Pub = require('../../models/api/pub')

//inserir user
module.exports.inserir = user => {
    return User.create(user);
}

//ver user por id
module.exports.consultar = (uid) => {
    return Pub
    .find({autorID: uid})
    .sort({data: -1})
    .exec()
}

//editar user
module.exports.editar = (uid) => {
    console.log(uid.id)
    return User
       .findByIdAndUpdate({_id: uid.id},{  
           $set : { 
            nome: uid.nome, 
            apelido:uid.apelido,
            email: uid.email
            
       }})
} 