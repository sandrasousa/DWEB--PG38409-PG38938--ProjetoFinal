var express = require('express');
var router = express.Router();
var axios = require('axios')
var jwt = require('jsonwebtoken')
var User = require('../models/api/user')
var cUser = require('../controllers/api/user')
var Pub = require('../controllers/api/pub')
var passport = require('passport')
const { ensureAuthenticated } = require('../config/auth');


//------------------------------------------------------------------
//---------------------------- UTILIZADOR---------------------------
//------------------------------------------------------------------

// GET home page
router.get('/', function(req, res, next) {
    res.render('index')
        .catch(erro => {
            res.render('error', {error: erro, message: 'Erro ao carregar pagina inicial'})
    })
});

// GET LOGIN
router.get('/login', function(req, res) {
    res.render('login', { User : req.User });
});

// POST LOGIN
router.post('/login', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/pubs',
    failureRedirect: '/',
    failureFlash: true
  })(req, res, next);
});

// GET REGISTO
router.get('/registo', (req, res) =>  {
  res.render('registo')
   
});

// POST /registo 
router.post('/registo', (req, res) =>  { 
    cUser.inserir(req.body)
      .then(res.redirect('/'))
      .catch(erro => res.status(500).send('Erro no registo.'))
});

// Devolve a informação de um utilizador
router.get('/user/:uid', ensureAuthenticated, (req, res) =>  {
  axios.get('http://localhost:4005/api/users/' + req.params.uid)
    .then(resposta => res.render('perfil', {pubs: resposta.data, id:req.user._id, nome:req.user.nome, email:req.user.email, apelido:req.user.apelido}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
        res.render('error', {error: erro, message: 'Erro ao carregar evento da Base de Dados'})
      })
});

// POST editar utilizador
router.post('/editar/user',ensureAuthenticated, (req, res) => {
  axios.post('http://localhost:4005/api/users/editar/', req.body)
    .then(resposta => res.redirect('http://localhost:4005/user/' + req.user._id))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/pubs')
    })
});

// GET LOGOUT
router.get('/logout', function(req, res) {
    req.logout();
    res.redirect('/');
});


//------------------------------------------------------------------
//--------------------------- PUBLICAÇÕES---------------------------
//------------------------------------------------------------------


/* GET /pubs */
router.get('/pubs', ensureAuthenticated, (req, res) => {
  axios.get('http://localhost:4005/api/pubs')
    .then(resposta => res.render('feed', { pubs: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/nova */
router.get('/pubs/nova',ensureAuthenticated, (req, res) => {
  axios.get('http://localhost:4005/api/pubs/nova')
    .then(resposta => res.render('nova', { pub: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/foto */
router.get('/pubs/foto',ensureAuthenticated, (req, res) => {
  axios.get('http://localhost:4005/api/pubs/foto')
    .then(resposta => res.render('foto', { pub: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/local */
router.get('/pubs/local',ensureAuthenticated, (req, res) => {
  axios.get('http://localhost:4005/api/pubs/local')
    .then(resposta => res.render('local', { pub: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});



/*GET /pubs/evento */
router.get('/pubs/evento', ensureAuthenticated, (req, res) => {
  axios.get('http://localhost:4005/api/pubs/evento')
    .then(resposta => res.render('evento', { pub: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
})

/* GET /pubs/:pid */
router.get('/pubs/:pid', ensureAuthenticated, (req, res) =>  {
  axios.get('http://localhost:4005/api/pubs/' + req.params.pid)
    .then(resposta => res.render('pub', { pub: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
        res.render('error', {error: erro, message: 'Erro ao carregar evento da Base de Dados'})
      })
});
  
  /* GET /pubs/tipo/:t */
  router.get('/pubs/tipo/:t', ensureAuthenticated, (req, res) =>  {
    axios.get('http://localhost:4005/api/pubs/tipo/' + req.params.t)
      .then(resposta => res.render('pub-tipo', { pubs: resposta.data, id:req.user._id, nome:req.user.nome}))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.render('error', {error: erro, message: 'Erro ao carregar tipo de publicação da Base de Dados'})
      })
  });
  
  /* GET /pubs/local/:l */
  router.get('/pubs/local/:l', ensureAuthenticated, (req, res) =>  {
    axios.get('http://localhost:4005/api/pubs/local/' + req.params.l)
      .then(resposta => res.render('pub-local', { pubs: resposta.data, id:req.user._id, nome:req.user.nome}))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.render('error', {error: erro, message: 'Erro ao carregar tipo de publicação da Base de Dados'})
      })
  });

/* GET /pubs/palavra */
router.get('/pubs/palavras/:p',ensureAuthenticated, (req, res) => {
  axios.get('http://localhost:4005/api/pubs/palavras/' + req.params.p)
    .then(resposta => res.render('pub-palavra', { pubs: resposta.data, id:req.user._id, nome:req.user.nome}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});  

  /* POST /pubs */
  router.post('/pubs',ensureAuthenticated, (req, res) =>  {
    axios.post('http://localhost:4005/api/pubs/', req.body)
      .then(() => res.redirect('http://localhost:4005/pubs'))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.redirect('http://localhost:4005/pubs')
      })
  });
  
  /* DELETE /pubs/:pid */
  router.post('/delete', ensureAuthenticated, (req, res) => {
    axios.post('http://localhost:4005/api/pubs/delete/', req.body)
      .then(resposta => res.redirect('http://localhost:4005/user/' + req.body.id))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.redirect('http://localhost:4005/user/'+ req.body.id)
      })
  });

    
   /* UPDATE /pubs*/ 
  router.post('/editar',ensureAuthenticated, (req, res) => {
    axios.post('http://localhost:4005/api/pubs/editar/', req.body)
      .then(resposta => res.redirect('http://localhost:4005/user/' + req.body.id))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.redirect('http://localhost:4005/pubs')
      })
  });
  
  /* UPDATE /pubs*/ 
  router.post('/comentario',ensureAuthenticated, (req, res) => {
    axios.post('http://localhost:4005/api/pubs/comentario/', req.body)
      .then(resposta => res.redirect('http://localhost:4005/pubs'))
      .catch(erro => {
        console.log('Erro ao carregar dados da BD.')
        res.redirect('http://localhost:4005/pubs')
      })
  });


    /* UPDATE /pubs*/ 
    router.post('/like',ensureAuthenticated, (req, res) => {
      var ref = req.get('Referrer')
      if(ref =="http://localhost:4005/pubs")
        axios.post('http://localhost:4005/api/pubs/like/', req.body)
            .then(resposta => res.redirect('http://localhost:4005/pubs'))
          .catch(erro => {
            console.log('Erro ao carregar dados da BD.')
            res.redirect('http://localhost:4005/pubs')
          })
      else if(ref.includes("http://localhost:4005/user/"))
        axios.post('http://localhost:4005/api/pubs/like/', req.body)
              .then(resposta => res.redirect('http://localhost:4005/user/'+req.user._id))
            .catch(erro => {
              console.log('Erro ao carregar dados da BD.')
              res.redirect('http://localhost:4005/user'+req.user._id)
            })
      else if(ref.includes("http://localhost:4005/pubs/tipo/"))
        axios.post('http://localhost:4005/api/pubs/like/', req.body)
              .then(resposta => res.redirect('http://localhost:4005/pubs/tipo/'+req.body.tipo))
            .catch(erro => {
              console.log('Erro ao carregar dados da BD.')
              res.redirect('http://localhost:4005/pubs/tipo/'+req.body.tipo)
            })
      else if(ref.includes("http://localhost:4005/pubs/local/"))
        axios.post('http://localhost:4005/api/pubs/like/', req.body)
              .then(resposta => res.redirect('http://localhost:4005/pubs/local/'+req.body.local))
            .catch(erro => {
              console.log('Erro ao carregar dados da BD.')
              res.redirect('http://localhost:4005/pubs/local/'+req.body.local)
            })
      else if(ref.includes("http://localhost:4005/pubs/"))
        axios.post('http://localhost:4005/api/pubs/like/', req.body)
              .then(resposta => res.redirect('http://localhost:4005/pubs/'+req.body._id))
            .catch(erro => {
              console.log('Erro ao carregar dados da BD.')
              res.redirect('http://localhost:4005/pubs/pubs/'+req.body._id)
            })


    });

module.exports = router;
