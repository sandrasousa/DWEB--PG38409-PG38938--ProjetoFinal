var express = require('express');
var router = express.Router();

var User = require('../../controllers/api/user')

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/:uid', (req,res)=>{
  User.consultar(req.params.uid)
      .then(dados => res.json(dados))
      .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})

router.post('/editar', (req,res)=>{
  User.editar(req.body)
      .then(dados => res.json(dados))
      .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})

module.exports = router;
