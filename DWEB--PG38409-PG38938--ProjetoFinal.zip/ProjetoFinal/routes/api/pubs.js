var express = require('express')
var router = express.Router()
var Pub = require('../../controllers/api/pub')

/* GET /api/pubs */
    //para obter a lista de publicações
router.get('/', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pubs/nova */
    //para obter a lista de novas publicações
router.get('/nova', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pubs/foto */
    //para obter a lista de novas fotos
router.get('/foto', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pubs/local */
    //para obter a lista de novos locais
router.get('/local', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pubs/evento */
    //para obter a lista de novos eventos
    router.get('/evento', (req,res)=>{
        Pub.listar()
            .then(dados => res.json(dados))
            .catch(erro => res.status(500).send('Erro na listagem das publicações'))
    })

/* GET /api/pub/:pid */ 
    //para obter publicações por id
router.get('/:pid', (req,res)=>{
    Pub.consultar(req.params.pid)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})
    

/* GET /api/pub/tipo/:t */ 
    //para obter publicações por tipo
router.get('/tipo/:t', (req,res)=>{
    Pub.listarTipo(req.params.t)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de eventos.'))
})

/* GET /api/pub/local/:l */ 
    //para obter publicações por tipo
router.get('/local/:l', (req,res)=>{
    Pub.listarLocal(req.params.l)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de eventos.'))
})

router.get('/palavras/:p', (req,res)=>{
    Pub.listarPalavra(req.params.p)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de eventos.'))
})

/* POST api/pubs */ 
    //para criar novas publicação/fotos/locais
router.post('/', (req,res)=>{
    Pub.inserir(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na inserção de publicações.'))
})

/* DELETE api/pubs/:pid */
router.post('/delete', (req,res) => {
    Pub.apagar(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})


/* UPDATE api/pubs/:pid */
router.post('/comentario', (req,res) => {
    Pub.comentar(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})

/* LIKE */
router.post('/like', (req,res) => {
    Pub.like(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})

/* UPDATE api/editar/:pid */
router.post('/editar', (req,res) => {
    Pub.editar(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})


module.exports = router;