var mongoose = require('mongoose')
var Schema = mongoose.Schema

var PubSchema = new Schema({
    estado: {type: String}, // privado (por defeito) ou público
    nome: {type: String}, // nome da publicação
    local: {type: String}, // localização da publicação 
    descricao: {type: String}, // descrição da publicação 
    dataInicio: {type: String}, // data de inicio (por defeito a presente data)
    dataFim: {type: String}, // data do fim da publicação 
    tipo: {type: String}, // tipo de publicação (desportivo, cultural, culinária)
    anexo: {data: Buffer, contentType: String},// anexos: fotos, videos 
    palavra: [{type: String}], 
    comentarios:[ {      
        autorID: {type: String},
        autorNome: {type: String},
        comentario: {type: String},
        data: {type: String} }], // correspondem aos comentários
    likes_count: {type: Number, default:0},
    autorID: {type: String},
    autorNome: {type: String}
})

module.exports = mongoose.model('Pub', PubSchema)


