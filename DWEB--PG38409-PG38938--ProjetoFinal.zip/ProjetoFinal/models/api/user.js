var mongoose = require('mongoose')
//modulo para encriptar a pass
var bcrypt = require('bcryptjs')
var Schema = mongoose.Schema


var UserSchema = new Schema({
    nome:{
        type: String,
        required: true
    },
    apelido: {
        type: String,
        required: true
    },
    email: {
        type: String,
        require: true,
        unique: true
    },
    password: {
        type: String,
        require: true
    } 
})

UserSchema.pre('save', async function(next){
    var hash = await bcrypt.hash(this.password, 10)
    this.password = hash
    next()
})

UserSchema.methods.isValidPassword = async function(password){
    var user = this
    var compare = await bcrypt.compare(password, user.password)
    return compare
}

var User = mongoose.model('User', UserSchema,'Users');

module.exports = User;