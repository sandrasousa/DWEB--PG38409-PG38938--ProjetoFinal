var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var app = express();
var urlencoded_body_parser = bodyParser.urlencoded({
    extended: true
});
var logger = require('morgan');
var mongoose = require('mongoose')

// ROTAS
var usersRouter = require('./routes/users');

var usersApiRouter = require('./routes/api/users');
var pubsApiRouter = require('./routes//api/pubs') 
var indexRouter = require('./routes/index');

var uuid = require('uuid/v4')
const flash = require('connect-flash');
const session = require('express-session');
var FileStore = require('session-file-store')(session)

var passport = require('passport')
var LocalStrategy = require('passport-local').Strategy
var axios = require('axios')

var User = require('./models/api/user')

var app = express();
app.locals.moment = require('moment');
// Passport Config
require('./config/passport')(passport);

// Base de Dados
///////conexão à BD PUB
mongoose.connect('mongodb://127.0.0.1:27017/pubs', {useNewUrlParser:true})
  .then(()=> console.log('Mongo ready: ' + mongoose.connection.readyState))
  .catch(()=> console.log('Erro de conexão'))



// Express session
app.use(
  session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
  })
);

//Inicialização do passport
app.use(passport.initialize())
app.use(passport.session())

app.use(flash());


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());

app.use(express.static(path.join(__dirname, 'public')));

// ROTAS


app.use('/users', usersRouter);// rota users
app.use('/api/users', usersApiRouter);// rota users
app.use('/api/pubs', pubsApiRouter); // rota das publicações
app.use('/', indexRouter);




// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



module.exports = app;
